package utils;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

public class DatabaseUtil {
    private static final String URL = "jdbc:mysql:///employees";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";
    public static Connection getConnection() throws ClassNotFoundException, SQLException{
    	try {
            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
