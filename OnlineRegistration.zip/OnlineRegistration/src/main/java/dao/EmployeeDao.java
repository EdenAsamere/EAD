package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Employee;
import utils.DatabaseUtil;

public class EmployeeDao {
    public int registerEmployee(Employee employee) {
        String query = "INSERT INTO employee(first_name, last_name, email, password, address, contact) VALUES(?,?,?,?,?,?);";
        int result = 0;
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, employee.getFirstName());
            ps.setString(2, employee.getLastName());
            ps.setString(3, employee.getEmail());
            ps.setString(4, employee.getPassword());
            ps.setString(5, employee.getAddress());
            ps.setString(6, employee.getContact());
            result = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed (e.g., log the error, throw a custom exception)
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return result;
    }
}
